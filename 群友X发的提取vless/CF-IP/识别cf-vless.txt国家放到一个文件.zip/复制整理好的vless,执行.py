print("请将vless节点复制保存到cf-vless.txt文件中，按下回车键执行脚本。")
input("按下回车键继续...")

import os
import re
import geoip2.database

# 国家代码到中文名称的映射字典
country_code_map = {
    'AD': '安道尔',
    'AE': '阿拉伯联合酋长国',
    'AF': '阿富汗',
    'AG': '安提瓜和巴布达',
    # 其他国家代码和中文名称的映射
    'CN': '中国',
    'US': '美国',
    'DE': '德国',
    'HK': '香港',
    'TW': '台湾',
    'JP': '日本',
    'KR': '韩国',
    'SG': '新加坡',
    'GB': '英国',
    'FR': '法国',
    'NL': '荷兰',
    'AU': '澳大利亚',
    'FI': '芬兰',
}

def process_file(file_path):
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            data = file.read()

            ipv4_set = set()
            ipv6_set = set()
            domain_set = set()

            ip_pattern = r'(\[?[0-9a-fA-F:]+\]?|\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}|[a-zA-Z0-9.-]+):(\d{1,5})'
            matches = re.findall(ip_pattern, data)

            for match in matches:
                ip = match[0]
                port = match[1]
                if ':' in ip:  # IPv6
                    ipv6_set.add(f"{ip}:{port}")
                elif '.' in ip:  # IPv4
                    ipv4_set.add(f"{ip}:{port}")
                else:  # Domain
                    domain_set.add(f"{ip}:{port}")

            reader = geoip2.database.Reader('GeoLite2-Country.mmdb')
            country_ip_map = {}

            for ip_port in ipv4_set.union(ipv6_set):
                ip = ip_port.split(':')[0]
                try:
                    response = reader.country(ip)
                    country_code = response.country.iso_code
                    if country_code in country_code_map:
                        country_name = country_code_map[country_code]
                        if country_name not in country_ip_map:
                            country_ip_map[country_name] = []
                        country_ip_map[country_name].append(ip_port)
                except:
                    pass

            output_folder = os.path.dirname(file_path)
            output_filename = os.path.join(output_folder, 'cf-vless-国家.txt')

            with open(output_filename, 'a') as output_file:
                for country_name, ips in country_ip_map.items():
                    for ip_port in ips:
                        output_file.write(f'{ip_port}#{country_name}\n')

            reader.close()

        print(f"处理文件 {os.path.basename(file_path)} 完成！")
    else:
        print(f"文件 {os.path.basename(file_path)} 不存在！")

# 指定处理的文件为 cf-vless.txt
file_path = 'cf-vless.txt'
process_file(file_path)
