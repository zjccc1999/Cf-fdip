import re

def add_number_after_hash(text):
    count_dict = {}
    text_dict = {}
    modified_lines = []
    
    for line in text.split('\n'):
        match = re.search(r'#(.+)', line)
        if match:
            text = match.group(1).strip()
            if text in text_dict:
                text_dict[text].append(line)
            else:
                text_dict[text] = [line]
    
    for text, lines in text_dict.items():
        count_dict[text] = 0
        for line in lines:
            count_dict[text] += 1
            count = count_dict[text]
            line = re.sub(r'#(.+)', f'#{text}{count}', line)
            modified_lines.append(line.strip())
    
    return '\n'.join(modified_lines)

def process_file(file_path):
    # 读取文件内容
    with open(file_path, 'r', encoding='utf-8') as file:
        text = file.read()

    # 处理文本
    text = add_number_after_hash(text)

    # 将修改后的内容写回文件
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(text)

# 调用函数处理文件
process_file("cf-vless-国家.txt")
