# 提取IP地址
cut -d',' -f1 result.csv | tail -n +2 > temp_ip.txt
ip=$(cat temp_ip.txt)

# 用户自定义字符
read -p "请输入自定义字符: " custom_char

# 获取当前时间
current_time=$(date +"%Y-%m-%d_%H-%M-%S")

# 生成带时间戳的文件名
file_name="${current_time}_GS.txt"

# 将内容写入带时间戳的文件
echo "$ip:$custom_char" > "$file_name"
echo "已生成带时间戳的文件: $file_name"

# 清理临时文件
rm temp_ip.txt
