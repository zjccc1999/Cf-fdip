import subprocess

ip_file = input("请输入IP地址文件名称：")
ip_count = input("请输入速度测试IP数量（默认 10）：")
ip_count = int(ip_count) if ip_count else 10
min_speed = input("请输入最低速度（默认 1）：")
min_speed = float(min_speed) if min_speed else 1
enable_tls = input("是否启用TLS？（默认 开）选1代表开，选2代表关：")
enable_tls = enable_tls != "2"  # True if enable_tls is not "2"

cmd = f"cfiptest.exe -f=\"{ip_file}\" -maxsc {ip_count} -mins {min_speed} -tls {str(enable_tls).lower()} -url https://speed.cloudflare.com/__down?bytes=100000000"

subprocess.run(cmd, shell=True)
